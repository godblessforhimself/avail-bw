#ifndef realtime_h__
#define realtime_h__

extern void lockMe();

#endif
